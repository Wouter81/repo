import xbmcaddon

MainBase = 'https://goo.gl/4Qorli'
addon = xbmcaddon.Addon('plugin.video.sr2016')